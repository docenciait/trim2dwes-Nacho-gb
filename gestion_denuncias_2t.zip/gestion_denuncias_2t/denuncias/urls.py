from django.urls import path
from . import views

urlpatterns = [
    path('', views.denuncias, name='denuncias.denuncias'),
    path('crear', views.crearDenuncias, name='crear_denuncia'),
    path('editar/<int:id>', views.editarDenuncias, name='denuncias.editar'),
    path('eliminar/<int:id>', views.eliminarDenuncias, name='eliminar'),
]