from django.shortcuts import render,redirect, get_object_or_404
from django.forms import modelformset_factory
from .models import Denuncia
from .forms import DenunciaForm
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required
def denuncias(request):
    template_data = {}
    template_data['denuncias'] = Denuncia.objects.all()
    return render(request, 'denuncias/denuncias.html', {'template_data': template_data})


@login_required
def crearDenuncias(request):
    template_data = {}
    if request.method == 'GET':
        template_data['form'] = DenunciaForm()
        return render(request, 'denuncias/create.html', {'template_data': template_data})
    elif request.method == 'POST':
        denuncia = Denuncia()
        denuncia.titulo = request.POST['titulo']
        denuncia.descripcion = request.POST['descripcion']
        denuncia.categoria = request.POST['categoria']
        denuncia.imagen= request.POST['imagen']
        denuncia.usuario=request.user
        denuncia.save()
        return redirect('denuncias.denuncias')
    else:
        return redirect('denuncias.denuncias')
    
@login_required    
def editarDenuncias(request, id):
    template_data = {}
    if request.method == 'GET':
        denuncia = Denuncia.objects.get(id=id)  
        form =  modelformset_factory(Denuncia, fields=["titulo","descripcion","imagen","categoria"])
        return render(request, 'denuncias/edit.html', {"formset": form})
    elif request.method == 'POST':
        denuncia = Denuncia.objects.get(id=id)
        denuncia.titulo = request.POST['form-0-titulo']
        denuncia.descripcion = request.POST['form-0-descripcion']
        denuncia.categoria = request.POST['form-0-categoria']
        denuncia.imagen= request.POST['form-0-imagen']
        denuncia.usuario=request.user
        denuncia.save()
        return redirect('denuncias.denuncias')
    else:
        return redirect('denuncias.denuncias')
    
@login_required
def eliminarDenuncias(request,id):
    template_data = {}
    if request.method == 'GET':
        denuncia = Denuncia.objects.get(id=id)
        template_data['titulo'] = denuncia.titulo
        return render(request, 'denuncias/eliminar.html', {'template_data': template_data})

    elif request.method == 'POST':
        denuncia = get_object_or_404(Denuncia, id=id)
        denuncia.delete()
        return redirect('denuncias.denuncias')
    else:
        return redirect('denuncias.denuncias')