from django import forms
from .models import CATEGORIAS, Denuncia


class DenunciaForm(forms.Form):
    titulo = forms.CharField(max_length=100)
    descripcion = forms.CharField(max_length=500)
    imagen = forms.ImageField()
    categoria = forms.CharField(
        max_length=1,
        widget=forms.Select(choices=CATEGORIAS),
    )
    