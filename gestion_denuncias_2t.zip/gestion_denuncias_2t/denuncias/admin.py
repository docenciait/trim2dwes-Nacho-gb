from django.contrib import admin
from .models import Denuncia

# Register your models here.

admin.site.register(Denuncia)