from django.urls import path
from . import views

urlpatterns = [
    path('registro/', views.registro, name='usuarios.registro'),
    path('login/', views.login, name='usuarios.login'),
    path('logout/', views.logout, name='usuarios.logout'),
]